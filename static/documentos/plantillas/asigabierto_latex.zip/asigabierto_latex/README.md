# Plantilla LaTeX para asignaturas en abierto (URJC)

Plantilla contribuida por Guille Carrión Santiago

